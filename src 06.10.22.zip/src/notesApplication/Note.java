package notesApplication;

import java.util.ArrayList;
import java.util.List;

public class Note {

	public static List<Note> notes = new ArrayList<>();
	private final String basePath = "C:\\Users\\91638\\eclipse-workspace\\NotesApplication";
	private String baseFolder = "\\Notes";
	private String fileName = "";
	private final String fileType = ".txt";
	private String filePath ;
	
	Note(String fileName){
		this.fileName = fileName;
	}
	
	Note(String baseFolder , String fileName){
		this.fileName = fileName;
		this.baseFolder = baseFolder; 
	}
	
	public void setFilePath() {
		this.filePath = this.basePath +"\\" +this.baseFolder + "\\" + this.fileName + this.fileType;
	}
	
	public String getFilePath() {
		return this.filePath;
	}
	
	public void setFolderBasePath() {
		this.filePath = this.basePath;
	}
	
	public String getFolderBasePath() {
		return this.filePath;
	}
	
	public void setFileBasePath() {
		this.filePath = this.basePath + "\\"+this.baseFolder ;
	}
	
	public String getFileBasePath() {
		return this.filePath;
	}

}
